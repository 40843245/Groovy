point a(1,1)
line a,b // b is referenced afterwards!
point b(5,2)