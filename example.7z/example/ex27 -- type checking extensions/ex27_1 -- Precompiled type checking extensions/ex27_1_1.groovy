/// Writing a type checking extension in Groovy is the easiest path. 
/// Basically, the idea is that the type checking extension script becomes the body of the main method of a type checking extension class.

import org.codehaus.groovy.transform.stc.GroovyTypeCheckingExtensionSupport

class PrecompiledExtension extends GroovyTypeCheckingExtensionSupport.TypeCheckingDSL {     
    @Override
    Object run() {                                                                          
        unresolvedVariable { var ->
            if ('robot'==var.name) {
                storeType(var, classNodeFor(Robot))                                         
                handled = true
            }
        }
    }
}

/// Setting up the extension is very similar to using a source form extension
config.addCompilationCustomizers(
    new ASTTransformationCustomizer(
        TypeChecked,
        extensions:['typing.PrecompiledExtension'])
)