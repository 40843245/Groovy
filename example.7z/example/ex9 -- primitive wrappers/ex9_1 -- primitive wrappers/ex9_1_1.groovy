class Foo {
    static int i
}

assert Foo.class.getDeclaredField('i').type == int.class           
assert Foo.i.class != int.class && Foo.i.class == Integer.class 