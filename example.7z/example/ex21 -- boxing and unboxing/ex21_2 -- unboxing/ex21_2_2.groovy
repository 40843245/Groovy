def (int i, String j) = [10, 'foo']
assert i == 10 && j == 'foo'