def (a, b) = [1, 2, 3] /// 3 will be ignored
assert a == 1 && b == 2