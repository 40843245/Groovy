def (a, b, c) = [1, 2] /// since c is excess to [1,2], c is specified with null.
assert a == 1 && b == 2 && c == null