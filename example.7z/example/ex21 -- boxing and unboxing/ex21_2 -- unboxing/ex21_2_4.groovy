def (_, month, year) = "18th June 2009".split()
assert "In $month of $year" == 'In June of 2009'