def (a, b, c) = [10, 20, 'foo']
assert a == 10 && b == 20 && c == 'foo'