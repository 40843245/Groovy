/// They are NOT total equivalent.
/// But they have same behaviour.
int x = 1
int y = 2
assert x+y == 3

x = 1
y = 2
assert x+y == 3