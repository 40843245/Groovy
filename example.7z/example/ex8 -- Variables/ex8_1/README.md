# NOTICE
> [!NOTE]
> Another approach to making a variable visible to all methods, 
> 
> is to use the [@Field annotation](https://docs.groovy-lang.org/latest/html/documentation/core-metaprogramming.html#xform-Field). 
> 
> A variable annotated this way will become a field of the generated script class and, 
> 
> as for local variables, access won’t involve the script `Binding`. 
> 
> While not recommended, if you have a local variable or script field with the same name as a binding variable, 
> 
> you can use `binding.varName` to access the binding variable.
