@CompileStatic                                                                  
class CompileDynamicProcessor extends AnnotationCollectorTransform {            
    private static final ClassNode CS_NODE = ClassHelper.make(CompileStatic)    
    private static final ClassNode TC_NODE = ClassHelper.make(TypeCheckingMode) 

    List<AnnotationNode> visit(AnnotationNode collector,                        
                               AnnotationNode aliasAnnotationUsage,             
                               AnnotatedNode aliasAnnotated,                    
                               SourceUnit source) {                             
        def node = new AnnotationNode(CS_NODE)                                  
        def enumRef = new PropertyExpression(
            new ClassExpression(TC_NODE), "SKIP")                               
        node.addMember("value", enumRef)                                        
        Collections.singletonList(node)                                         
    }
}