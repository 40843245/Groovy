@interface Timout{ // define an annotation named `Timout`
    Integer after()
}

@interface Dangerous{ // define an annotation named `Dangerous`
    String type()
}

/// example of using multiple annotation.
@Timeout(after=3600)
@Dangerous(type='explosive')
@AnnotationCollector
public @interface Explosive {}

/// using a meta annotation with default value `after:3600` and type:'explosive' (defined above)
@Explosive()                 
class Explosives {}

/// using a meta annotation with default value `type:'explosive'` and specified value `after:0`.
@Explosive(after = 0)                 
class Bomb {}