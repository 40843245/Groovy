@interface Service{} // define an annotation named `Service`
@interface Transactional{} // define an annotation named `Service`

/**
    They are equivalent,
    For more details, see [`Meta annotations`](https://www.groovy-lang.org/objectorientation.html#_meta_annotations)
**/

/// example of using multiple annotation.
@Service
@Transactional
class MyTransactionalService {}

/// example of meta annotation
/// Since `@Service` and `@Transactional` has same semantics, they can be written as `@TransactionalService` (which is a meta annotation)
/// which is equivalent to 
/// ```
/// @Service
/// @Transactional
/// ```
/// with `@AnnotationCollector` annotation 
/// as following example.

import groovy.transform.AnnotationCollector

@Service                                        
@Transactional                                  
@AnnotationCollector                            
@interface TransactionalService {}

@TransactionalService                           
class MyTransactionalService {}

