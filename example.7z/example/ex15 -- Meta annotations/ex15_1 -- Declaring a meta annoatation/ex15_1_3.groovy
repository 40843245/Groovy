/// explained in [`Meta annotations`](https://www.groovy-lang.org/objectorientation.html#_meta_annotations)
@Retention(RetentionPolicy.RUNTIME)
public @interface Foo {
   String value()                                   
}
@Retention(RetentionPolicy.RUNTIME)
public @interface Bar {
    String value()                                  
}

@Foo
@Bar
@AnnotationCollector
public @interface FooBar {}                         

@Foo('a')
@Bar('b')
class Bob {}                                        

assert Bob.getAnnotation(Foo).value() == 'a'        
println Bob.getAnnotation(Bar).value() == 'b'       

@FooBar('a')
class Joe {}                                        
assert Joe.getAnnotation(Foo).value() == 'a'        
println Joe.getAnnotation(Bar).value() == 'a'  