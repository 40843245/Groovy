@Service
@Transactional
class MyTransactionalService {}

def annotations = MyTransactionalService.annotations*.annotationType()
assert (Service in annotations)
assert (Transactional in annotations)