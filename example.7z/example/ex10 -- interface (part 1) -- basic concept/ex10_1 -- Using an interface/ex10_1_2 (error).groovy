interface Greeter {
    protected void greet(String name) // compile-time error.
}