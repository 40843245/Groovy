interface Greeter {                                         
    void greet(String name)                                 
}

class SystemGreeter implements Greeter {                    
    void greet(String name) {                               
        println "Hello $name"
    }
}

def greeter = new SystemGreeter()
assert greeter instanceof Greeter 