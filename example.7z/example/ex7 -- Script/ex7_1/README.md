# NOTICE
> [!NOTE]
> Even if Groovy creates a class from your script,
>  
> it is totally transparent for the user. 
> 
> In particular, scripts are compiled to bytecode, and line numbers are preserved. 
> 
> This implies that if an exception is thrown in a script, 
> 
> the stack trace will show line numbers corresponding to the original script, 
>
> not the generated code that we have shown.