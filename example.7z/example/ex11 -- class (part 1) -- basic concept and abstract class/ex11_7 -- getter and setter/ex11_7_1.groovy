/// a class that will be a class that satisfies JavaBean rules after compilation.
class Person {
    String name // Groovy compiler will generate a backing private String name field, a getName and a setName method                   
    int age // Similarly, it will generate a backing private int age field, a getAge and a setAge method
}