/// a class that will be a class that does NOT satisfies Javabeans' rule after compilation.
class Person {
    final String name // Groovy compiler will NOT generate a backing private String name field, a getName and a setName method since it can assigned at most once due to `final` modifier.            
    final int age // Similary.                      
    Person(String name, int age) {
        this.name = name                
        this.age = age                  
    }
}