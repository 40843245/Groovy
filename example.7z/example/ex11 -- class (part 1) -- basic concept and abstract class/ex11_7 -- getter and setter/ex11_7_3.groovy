class Person {
    String name
    void name(String name) {  // a method behaves as a setter of name property.
        this.name = "Wonder $name"      
    }
    String title() { // a method behaves as a getter of name property.
        this.name                       
    }
}

def p = new Person()
p.name = 'Diana'                        
assert p.name == 'Diana'                
p.name('Woman')                         
assert p.title() == 'Wonder Woman' 