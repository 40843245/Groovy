# NOTICE
> [!NOTE]
> Property names starting with a capital letter would have getters/setters with just the prefix added. 
>
> So, the property `Foo` is allowed even though it isn’t following the recommended naming conventions. 
> 
> For this property, the accessor methods would be `setFoo` and `getFoo`. 
> 
> A consequence of this is that you aren’t allowed to have both a `foo` and a `Foo` property, 
> 
> since they would have the same named accessor methods.

For more details, see [`Property naming conventions`](https://www.groovy-lang.org/objectorientation.html#_property_naming_conventions)
