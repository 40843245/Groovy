class BadPractice {
    private mapping  // NOT declaring type, a property with week type.                       
}