class GoodPractice {
    private Map<String,String> mapping  // Declares type, a property with strong type.
}