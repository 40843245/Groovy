class Animal{
    String publicProperty1 // By default, a public property.
    public String publicProperty2 // a public property.
    private String privateProperty1 // a private property.
    protected String protectedProperty1 // a protected property.
    public static final Boolean DEBUG = false // a public, static, NOT reassignablle property.
}