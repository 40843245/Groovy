# NOTICE
> [!NOTE]
> By convention, Groovy will generate psuedo-properties 
> 
> provided there are getters or setters that follow the Java Beans specification,
> 
> even if there is no backing field.