class HasPropertyWithProtectedField {
    String name // Declare name property
    protected String name  // 	Protected backing field for name property instead of normal private one
}