class HasPropertyWithSynchronizedAccessorMethods {
    @Synchronized String name // Declare name property with annotation for setter/getter
    private String name // Backing field for name property 
}