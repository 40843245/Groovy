class HasPropertyWithPackagePrivateField {
    String name // Declare name property
    @PackageScope String name // Package-private backing field for name property instead of normal private one
}