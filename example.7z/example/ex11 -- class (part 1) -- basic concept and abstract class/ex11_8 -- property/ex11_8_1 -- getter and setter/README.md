# See also
See examples from `example/ex11/ex11_7 -- getter and setter`.