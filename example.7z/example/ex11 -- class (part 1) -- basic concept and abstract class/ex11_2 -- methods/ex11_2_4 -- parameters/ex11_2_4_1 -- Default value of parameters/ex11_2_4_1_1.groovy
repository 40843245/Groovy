def foo(String par1, Integer par2 = 1) { [name: par1, age: par2] }
fooInst = foo('Marie') // Since the parameter - `par2` is NOT specified, it is specified to default value `1`. Thus `age` is equal to `1`.
assert fooInst.age == 1 