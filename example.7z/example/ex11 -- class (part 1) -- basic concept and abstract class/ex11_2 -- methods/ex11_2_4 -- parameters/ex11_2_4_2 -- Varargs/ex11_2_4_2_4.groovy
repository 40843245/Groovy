def foo(Object... args) { args }
Integer[] ints = [1, 2]
assert foo(ints) == [1, 2]