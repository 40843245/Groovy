def foo(Object... args) { args }
assert foo(null) == null