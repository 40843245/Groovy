/// example of varargs with array-style, analogous to defining a parameter with Array<Object> in Java.  
def foo(Object[] args) { args.length }
assert foo() == 0
assert foo(1) == 1
assert foo(1, 2) == 2