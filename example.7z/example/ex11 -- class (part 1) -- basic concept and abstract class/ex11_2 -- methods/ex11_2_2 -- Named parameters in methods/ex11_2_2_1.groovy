def foo(Map args) { "${args.name}: ${args.age}" }
foo(name: 'Marie', age: 1)