abstract class AbstractClass { // abstract class        
    String name // non-abstract property

    abstract def abstractMethod() // abstract methid

    def concreteMethod() { // non-abstract method
        println 'concrete'
    }
}