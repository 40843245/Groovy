class Outer3 {
    private String privateStr = 'some string'

    def startThread() {
        // Looks like code snippets that implements `Runnable` interface in Java, does not it?
        new Thread(new Runnable() {      
            void run() {
                println "${privateStr}."
            }
        }).start()                       
    }
}