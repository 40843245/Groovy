import static java.lang.Math.*

assert sin(0) == 0.0
assert cos(0) == 1.0