import static Boolean.FALSE

assert !FALSE //use directly, without Boolean prefix!