import static Calendar.getInstance as now

assert now().class == Calendar.getInstance().class