final class Circle implements ShapeI { }
final class Square implements ShapeI { }

sealed class Shape permits Circle,Polygon,Rectangle { }