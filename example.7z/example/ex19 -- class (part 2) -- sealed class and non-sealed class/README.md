# NOTICE
> [!NOTE]
> `non-sealed` is a modifier for Groovy version 4 or above although it contains a dash.