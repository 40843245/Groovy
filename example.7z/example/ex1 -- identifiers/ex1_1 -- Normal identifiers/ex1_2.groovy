foo.as
foo.assert
foo.break
foo.case
foo.catch