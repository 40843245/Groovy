def name
def item3
def with_underscore
def $dollarStart