#!/usr/bin/env groovy

// A Shebang line
println "Hello from the shebang line"