// a standalone single line comment
println "hello" // a comment till the end of the line

