# mnemonic
> [!TIP]
> It is designed to `record` in Java.