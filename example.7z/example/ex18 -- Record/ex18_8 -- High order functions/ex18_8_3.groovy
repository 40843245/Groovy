record Point(int x, int y, String color) { }

def p = new Point(100, 200, 'green')
assert p.size() == 3