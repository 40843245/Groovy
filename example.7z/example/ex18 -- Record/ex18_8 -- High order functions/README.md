# NOTICE
> [!NOTE]
> Groovy has a limited number of `TupleN` classes. 
> 
> If you have a large number of components in your record, you might not be able to use this feature.