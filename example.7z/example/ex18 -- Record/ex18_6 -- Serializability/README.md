# NOTICE
> [!NOTE]
> Groovy _native_ records follow the [special conventions](https://docs.oracle.com/en/java/javase/16/docs/specs/records-serialization.html) for serializability which apply to Java records. 
> 
> Groovy _record-like_ classes (discussed below) follow normal Java class serializability conventions.