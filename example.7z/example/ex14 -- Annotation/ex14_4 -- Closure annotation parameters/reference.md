# reference
## guide reference
See [`Closure annotation parameters`](https://www.groovy-lang.org/objectorientation.html#_closure_annotation_parameters)