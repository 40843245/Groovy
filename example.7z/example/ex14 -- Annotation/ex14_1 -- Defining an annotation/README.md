# NOTICE
> [!NOTE]
> The list of possible targets is available in the [java.lang.annotation.ElementType](https://docs.oracle.com/en/java/javase/11/docs/api/index.html?java/lang/annotation/ElementType.html).

> [!WARNING]
> Groovy does not support the [java.lang.annotation.ElementType#TYPE\_PARAMETER](https://docs.oracle.com/en/java/javase/11/docs/api/index.html?java/lang/annotation/ElementType.html#TYPE_PARAMETER) and [java.lang.annotation.ElementType#TYPE\_PARAMETER](https://docs.oracle.com/en/java/javase/11/docs/api/index.html?java/lang/annotation/ElementType.html#TYPE_PARAMETER) element types which were introduced in Java 8.

For more details, see the doc -- [Annotation placement`](https://www.groovy-lang.org/objectorientation.html#ann-placement) and its offered docs.