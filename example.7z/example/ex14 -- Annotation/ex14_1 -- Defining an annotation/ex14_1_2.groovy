/// an example to restrict the use of your own declared annotation.
import java.lang.annotation.ElementType
import java.lang.annotation.Target

@Target([ElementType.METHOD, ElementType.TYPE])     
@interface SomeAnnotation {}  