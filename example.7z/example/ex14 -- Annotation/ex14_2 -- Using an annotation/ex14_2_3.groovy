@interface Page {
    String value()
    int statusCode() default 200
}

@Page(value='/home')                    
void home() {
    // ...
}

@Page('/users')                         
void userList() {
    // ...
}

@Page(value='error',statusCode=404)     
void notFound() {
    // ...
}