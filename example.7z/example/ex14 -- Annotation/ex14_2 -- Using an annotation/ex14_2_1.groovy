@interface SomeAnnotation {
    String value()                          
}
@interface SomeAnnotation {
    String value() default 'something'      
}
@interface SomeAnnotation {
    int step()                              
}
@interface SomeAnnotation {
    Class appliesTo()                       
}
@interface SomeAnnotation {}
@interface SomeAnnotations {
    SomeAnnotation[] value()                
}
enum DayOfWeek { mon, tue, wed, thu, fri, sat, sun }
@interface Scheduled {
    DayOfWeek dayOfWeek()                   
}

@SomeAnnotation                 
void someMethod() {
    // ...
}

@SomeAnnotation                 
class SomeClass {}

@SomeAnnotation String var