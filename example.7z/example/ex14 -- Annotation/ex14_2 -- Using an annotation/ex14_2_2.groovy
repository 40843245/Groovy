@interface Page {
    int statusCode()
}

@Page(statusCode=404)
void notFound() {
    // ...
}