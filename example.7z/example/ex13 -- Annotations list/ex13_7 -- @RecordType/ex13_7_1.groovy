@RecordType
class Message {
    String from
    String to
    String body
}