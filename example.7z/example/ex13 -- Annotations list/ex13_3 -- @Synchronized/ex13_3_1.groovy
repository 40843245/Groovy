class HasPropertyWithSynchronizedAccessorMethods {
    private String name        
    @Synchronized String name  
}