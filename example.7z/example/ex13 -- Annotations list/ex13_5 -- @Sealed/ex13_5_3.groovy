final class Foo implements FooTrait {}

/// They are equivalent if they are put in same source file.
@Sealed(permittedSubclasses='Foo') 
trait FooTrait {}

@SelfType(Foo)
trait FooTrait {}