# reference
## guide reference
See [`Differences with Sealed annotation (incubating)`](https://www.groovy-lang.org/objectorientation.html#_differences_with_sealed_annotation_incubating)