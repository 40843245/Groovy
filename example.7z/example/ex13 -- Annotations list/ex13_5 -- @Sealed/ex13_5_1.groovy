/**
    They are equivalent 
**/
/// (1)
@Sealed(permittedSubclasses=[Circle,Square]) /// mark the interface `ShapeI` can be implemented by `Circle` and `Square`.
interface ShapeI { } 
final class Circle implements ShapeI { }
final class Square implements ShapeI { }

/// (2)
sealed interface ShapeI permits Circle,Square { }
final class Circle implements ShapeI { }
final class Square implements ShapeI { }