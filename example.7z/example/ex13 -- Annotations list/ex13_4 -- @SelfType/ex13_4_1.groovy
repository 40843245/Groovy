class CommunicationService {
    static void sendMessage(String from, String to, String message) {       
        println "$from sent [$message] to $to"
    }
}

class Device { String id }                                                  

trait Communicating {
    void sendMessage(Device to, String message) {
        CommunicationService.sendMessage(id, to.id, message)                
    }
}

@SelfType(Device)
@CompileStatic
trait Communicating {
    void sendMessage(Device to, String message) {
        SecurityService.check(this)
        CommunicationService.sendMessage(id, to.id, message)
    }
}