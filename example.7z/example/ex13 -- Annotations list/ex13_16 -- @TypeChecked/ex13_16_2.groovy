@TypeChecked(extensions='/path/to/myextension.groovy')
void foo() {
    // ... 
}