class HasPropertyWithPackagePrivateField {
    String name                
    @PackageScope String name  
}