@RecordOptions(size=false)
record Point(int x, int y, String color) { }

def p = new Point(100, 200, 'green')
p.size() // Compiler error since the high order function `size` feature is disabled through `@RecordOptions(size=false)`.