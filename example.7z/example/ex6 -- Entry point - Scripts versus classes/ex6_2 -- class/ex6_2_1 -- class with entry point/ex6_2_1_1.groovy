// Main.groovy
class Main {                                    
    static void main(String... args) {          
        println 'Groovy world!'                 
    }
}