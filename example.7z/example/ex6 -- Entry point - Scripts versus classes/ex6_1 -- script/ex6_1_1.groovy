// Main.groovy
println 'Groovy world!'