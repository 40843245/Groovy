def y = 5

while ( y-- > 0 ) {
    println(y)
}
println("Finally, y:${y}")