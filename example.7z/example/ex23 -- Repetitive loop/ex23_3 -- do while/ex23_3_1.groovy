// classic Java-style do..while loop
def count = 5
do {
    println(count)
    count--
} while(count > 1)
println("Finally count:${count}")