// iterate over a range
for ( i in 0..9 ) {
    println(i)
}