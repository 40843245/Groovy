// iterate over a map
def map = ['abc':1, 'def':2, 'xyz':3]
for ( e in map ) {
    println("${e.key} => ${e.value}")
}