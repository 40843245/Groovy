interface MessageHandler {
    void on(String message, Map payload)
}

trait DefaultHandler implements MessageHandler {
    void on(String message, Map payload) {
        println "Received $message with payload $payload"
    }
}

trait LoggingHandler implements MessageHandler {                            
    void on(String message, Map payload) {
        println "Seeing $message with payload $payload"                     
        super.on(message, payload)                                          
    }
}

trait SayHandler implements MessageHandler {
    void on(String message, Map payload) {
        if (message.startsWith("say")) {                                    
            println "I say ${message - 'say'}!"
        } else {
            super.on(message, payload)                                      
        }
    }
}

class Handler implements DefaultHandler, SayHandler, LoggingHandler {}
def h = new Handler()
h.on('foo', [:])
h.on('sayHello', [:])

class AlternateHandler implements DefaultHandler, LoggingHandler, SayHandler {}
h = new AlternateHandler()
h.on('foo', [:])
h.on('sayHello', [:])