interface MessageHandler {
    void on(String message, Map payload)
}

trait DefaultHandler implements MessageHandler {
    void on(String message, Map payload) {
        println "Received $message with payload $payload"
    }
}

class SimpleHandler implements DefaultHandler {}

class SimpleHandlerWithLogging implements DefaultHandler {
    void on(String message, Map payload) {                                  
        println "Seeing $message with payload $payload"                     
        DefaultHandler.super.on(message, payload)                           
    }
}