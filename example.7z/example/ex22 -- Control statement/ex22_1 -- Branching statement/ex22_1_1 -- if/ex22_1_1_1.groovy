def x = false

if ( !x ) {
    println("x is false.")
}else{
    println("x is true.")
}

println()

if ( x ) {
    println("x is true.")
}else{
    println("x is false.")
}
