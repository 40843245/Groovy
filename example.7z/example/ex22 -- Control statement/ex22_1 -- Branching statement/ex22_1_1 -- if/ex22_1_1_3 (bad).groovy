def number1 = 2

if(number1 > 0 ){
    println("number1 is greater than 0")
}else{
    if(number1 == 0){
        println("number1 is equal to 0")
    }else{
        println("number1 is less than 0")
    }
}