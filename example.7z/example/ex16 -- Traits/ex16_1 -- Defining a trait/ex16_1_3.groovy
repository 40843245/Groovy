trait Greeter {
    private String greetingMessage() {                      
        'Hello from a private method!'
    }
    String greet() {
        def m = greetingMessage()                           
        println m
        m
    }
}