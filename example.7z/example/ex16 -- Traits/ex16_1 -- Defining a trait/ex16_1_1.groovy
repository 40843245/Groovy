trait FlyingAbility { // declaration of a trait              
    String fly() { "I'm flying!" }  // 	declaration of a method inside a trait        
}