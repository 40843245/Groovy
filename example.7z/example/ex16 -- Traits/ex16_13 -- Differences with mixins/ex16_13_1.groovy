class A { String methodFromA() { 'A' } }        
class B { String methodFromB() { 'B' } }        
A.metaClass.mixin B                             
def o = new A()
assert o.methodFromA() == 'A'                   
assert o.methodFromB() == 'B'                   
assert o instanceof A                           
assert !(o instanceof B)   