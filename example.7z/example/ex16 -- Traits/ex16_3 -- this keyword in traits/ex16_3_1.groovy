/// example of this keyword in trait
trait Introspector {
    def whoAmI() { this } // return identical instance.
}
class Foo implements Introspector {}
def fooInst1 = new Foo()
def fooInst2 = fooInst1.whoAmI()

assert fooInst2.is(fooInst1)