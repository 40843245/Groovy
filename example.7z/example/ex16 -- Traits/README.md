# NOTICE
> [!NOTE]
> Traits only support `public` and `private` methods. 
> 
> Neither `protected` nor `package private` scopes are supported.