trait Filtering {                                       
    StringBuilder append(String str) {                  
        def subst = str.replace('o','')                 
        super.append(subst)                             
    }
    String toString() { super.toString() }              
}
def sb = new StringBuilder().withTraits Filtering       
sb.append('Groovy')
assert sb.toString() == 'Grvy' 