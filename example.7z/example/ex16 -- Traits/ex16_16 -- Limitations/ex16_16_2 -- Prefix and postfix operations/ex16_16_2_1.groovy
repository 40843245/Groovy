
/// Within traits, prefix and postfix operations are not allowed if they update a field of the trait.
/// As postfix is not allowed. 
/// One way to resolve this issue is to add methods to perform prefix or postfix operations then call the defined method. As defining a method.
/// Other way to resolve this issue is to use compound assignment operator (such as `+=`, `-=`) 
/// NOTE that 
/// a sole expression `a++` can be `a+=1` and so is `++a`.
/// Similarly, a sole expression `a--` can be `a-=1` and so is `--a`.
trait Counting {
    int x
    void inc() {
        x++                             
    }
    void dec() {
        --x                             
    }
}
class Counter implements Counting {}
def c = new Counter()
c.inc()