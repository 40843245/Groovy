trait FlyingAbility { // declaration of a trait              
    String fly() { "I'm flying!" }  // 	declaration of a method inside a trait        
}

class Bird implements FlyingAbility {}          
def b = new Bird()                              
assert b.fly() == "I'm flying!"   