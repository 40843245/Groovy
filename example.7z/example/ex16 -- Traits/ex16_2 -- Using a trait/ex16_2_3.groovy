trait Greeter {
    private String greetingMessage() {                      
        'Hello from a private method!'
    }
    String greet() {
        def m = greetingMessage()                           
        println m
        m
    }
}
class GreetingMachine implements Greeter {}                 
def g = new GreetingMachine()
assert g.greet() == "Hello from a private method!"          
try {
    assert g.greetingMessage()                              
} catch (MissingMethodException e) {
    println "greetingMessage is private in trait"
}