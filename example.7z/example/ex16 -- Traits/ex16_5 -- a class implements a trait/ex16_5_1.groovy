trait Named {
    String name                             
}
class Person implements Named {}            
def p = new Person(name: 'Bob')             
assert p.name == 'Bob'                      
assert p.getName() == 'Bob' 