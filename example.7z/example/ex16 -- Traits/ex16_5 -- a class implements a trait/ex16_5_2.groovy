trait Counter {
    private int count = 0                   
    int count() { count += 1; count }       
}
class Foo implements Counter {}             
def f = new Foo()
assert f.count() == 1                       
assert f.count() == 2