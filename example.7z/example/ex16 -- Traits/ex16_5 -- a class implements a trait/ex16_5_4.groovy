trait FlyingAbility {                           
    String fly() { "I'm flying!" }          
}
trait SpeakingAbility {
    String speak() { "I'm speaking!" }
}

class Flyer implements FlyingAbility, SpeakingAbility {} 

class Duck implements FlyingAbility, SpeakingAbility {
    String quack() { "Quack!" }                 
    String speak() { quack() }   // overriding speak method in `SpeakingAbility` trait.                   
}

def flyer = new Flyer()
assert flyer.fly() == "I'm flying!"                         
assert flyer.speak() == "I'm speaking!"  

def duck = new Duck()
assert duck.fly() == "I'm flying!" 
assert duck.speak() == "Quack!"                        
assert duck.quack() == "Quack!"                           