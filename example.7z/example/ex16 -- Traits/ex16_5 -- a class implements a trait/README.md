# NOTICE
> [!NOTE]
> This is a major difference with [Java 8 virtual extension methods](http://docs.oracle.com/javase/tutorial/java/IandI/defaultmethods.html). 
>
> While virtual extension methods do not carry state, 
> 
> traits can.
>
> Moreover, traits in Groovy are supported starting with Java 6, 
> 
> because their implementation does not rely on virtual extension methods. 
> 
> This means that even if a trait can be seen from a Java class as a regular interface, 
> 
> that interface will **not** have default methods, only abstract ones.