trait Named {
    String name                                     
}
trait Polite extends Named {                        
    String introduce() { "Hello, I am $name" }      
}
class Person implements Polite {}
def p = new Person(name: 'Alice')                   
assert p.introduce() == 'Hello, I am Alice'   