trait WithId {                                      
    Long id
}
trait WithName {                                    
    String name
}

/// multiple inheritence
trait Identified implements WithId, WithName {}  