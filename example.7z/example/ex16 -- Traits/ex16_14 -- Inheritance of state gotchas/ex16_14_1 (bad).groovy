trait IntCouple {
    int x = 1
    int y = 2
    int sum() { x+y } // always returns `1+2` as x is initialized to 1 and y is initialized to 2 
    /// and this method is bound at initialized value of property `x` and `y` 
    /// (or simply said, it is computed when `IntCouple` instance is instantiated.)
}

class BaseElem implements IntCouple {
    int f() { sum() }
}
def base = new BaseElem()
assert base.f() == 3

class Elem implements IntCouple {
    int x = 3 // overriding property `x` in `IntCouple` trait            
    int y = 4 // overriding property `x` in `IntCouple` trait 
    int f() { sum() } // but still return `1`+`2` since `sum` call uses initialized property `x` and `y` to compute the expression `x+y`.
}
def elem = new Elem()