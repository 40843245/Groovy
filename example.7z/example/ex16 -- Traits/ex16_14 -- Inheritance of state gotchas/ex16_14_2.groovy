trait IntCouple {
    int x = 1 // automatically generate psuedo-getter getX() and psuedo-setter setX()
    int y = 2 // automatically generate psuedo-getter getY() and psuedo-setter setY()
    int sum() { getX()+getY() } /// does NOT always returns `1+2`, when either property of `x` and `y` is overridden, this phenomenon occur 
    /// since it is computed at runtime (exactly said, when `sum` method is called) 
    /// as it uses getter.
}

class BaseElem implements IntCouple {
    int f() { sum() }
}
def base = new BaseElem()
assert base.f() == 3

class Elem implements IntCouple {
    int x = 3 // overriding property `x` in `IntCouple` trait            
    int y = 4 // overriding property `x` in `IntCouple` trait 
    int f() { sum() } // but still return `1`+`2` since `sum` call uses initialized property `x` and `y` to compute the expression `x+y`.
}
def elem = new Elem()