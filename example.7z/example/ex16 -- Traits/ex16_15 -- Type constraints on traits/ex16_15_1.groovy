class CommunicationService {
    static void sendMessage(String from, String to, String message) {       
        println "$from sent [$message] to $to"
    }
}

class Device { String id }                                                  

trait Communicating {
    void sendMessage(Device to, String message) {
        CommunicationService.sendMessage(id, to.id, message)                
    }
}

class MyDevice extends Device implements Communicating {}                   

class SecurityService {
    static void check(Device d) { if (d.id==null) throw new SecurityException() }
}

def bob = new MyDevice(id:'Bob')
def alice = new MyDevice(id:'Alice')
bob.sendMessage(alice,'secret') 