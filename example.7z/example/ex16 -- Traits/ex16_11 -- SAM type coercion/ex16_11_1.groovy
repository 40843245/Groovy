trait Greeter {
    /// psuedo-property read-only `name`
    String greet() { "Hello $name" }        
    abstract String getName()               
}


Greeter greeter = { 'Alice' } // print `Hello Alice`

void greet(Greeter g) { println g.greet() } 
greet { 'Alice' }  // print `Hello Alice`