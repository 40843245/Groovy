trait A { void methodFromA() {} }
trait B { void methodFromB() {} }

class C {}

def c = new C()
c.methodFromA() // a runtime exception               
c.methodFromB() // a runtime exception                    
def d = c.withTraits A, B           
d.methodFromA()                     
d.methodFromB()  