trait A {
    String exec() { 'A' }               
}
trait B {
    String exec() { 'B' }               
}
class C implements A,B {} 

def c = new C()
assert c.exec() == 'B'