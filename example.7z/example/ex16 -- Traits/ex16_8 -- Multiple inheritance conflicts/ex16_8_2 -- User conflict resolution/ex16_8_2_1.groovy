trait A {
    String exec() { 'A' }               
}
trait B {
    String exec() { 'B' }               
}

class C implements A,B {
    String exec() { A.super.exec() }    
}
def c = new C()
assert c.exec() == 'A' 