trait DynamicObject {                               
    private Map props = [:]
    def methodMissing(String name, args) {
        name.toUpperCase()
    }
    def propertyMissing(String name) {
        props.get(name)
    }
    void setProperty(String name, Object value) {
        props.put(name, value)
    }
}

class Dynamic implements DynamicObject {
    String existingProperty = 'ok'                  
    String existingMethod() { 'ok' }                
}
def d = new Dynamic()
assert d.existingProperty == 'ok'                   
assert d.foo == null                                
d.foo = 'bar'                                       
assert d.foo == 'bar'                               
assert d.existingMethod() == 'ok'                   
assert d.someMethod() == 'SOMEMETHOD' 