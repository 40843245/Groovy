def fooPattern = /.*foo.*/
assert fooPattern == '.*foo.*'