def multilineSlashy = /one
    two
    three/

assert multilineSlashy.contains('\n')