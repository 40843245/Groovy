def escapeSlash = /The character \/ is a forward slash/
assert escapeSlash == 'The character / is a forward slash'