// \u20AC is an Euro currency symbol
'The Euro currency symbol: \u20AC'