// a kind of plain string
// Can not perform string interpolation for a plain string.
'a single-quoted string'