def aMultilineString = '''line one
line two
line three'''