def startingAndEndingWithANewline = '''
line one
line two
line three
'''