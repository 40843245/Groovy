'''a triple-single-quoted string'''
