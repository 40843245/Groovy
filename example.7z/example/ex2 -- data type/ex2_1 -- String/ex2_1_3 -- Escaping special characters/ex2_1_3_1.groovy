'an escaped single quote: \' needs a backslash'
