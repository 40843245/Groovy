// Here, the closure takes a single java.io.StringWriter argument, 
// to which you can append content with the << leftShift operator. 
// In either case, both placeholders are embedded closures.
def oneParamClosureString = "1 + 2 == ${ w -> w << 3}" 
assert oneParamClosureString == '1 + 2 == 3'