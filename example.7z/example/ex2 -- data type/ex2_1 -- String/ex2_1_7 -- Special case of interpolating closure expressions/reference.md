# reference
## guide reference
See [` Special case of interpolating closure expressions`](https://groovy-lang.org/syntax.html#_special_case_of_interpolating_closure_expressions)