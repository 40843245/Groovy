// The closure is a parameterless closure which doesn’t take arguments.
def parameterLessClosureString = "1 + 2 == ${-> 3}" 
assert parameterLessClosureString == '1 + 2 == 3'