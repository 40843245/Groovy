assert "one: ${1}".hashCode() != "one: 1".hashCode()
