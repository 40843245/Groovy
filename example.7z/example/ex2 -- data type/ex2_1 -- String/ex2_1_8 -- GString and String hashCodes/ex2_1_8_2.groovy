def key = "a"
def m = ["${key}": "letter ${key}"]     

assert m["a"] == null   