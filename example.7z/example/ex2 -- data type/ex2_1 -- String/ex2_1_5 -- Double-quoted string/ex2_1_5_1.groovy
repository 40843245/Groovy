// a GString which only can perform string interpolation.
// Can not perform string interpolation for a plain string.
"a double-quoted string"