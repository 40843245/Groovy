// also valid, but NOT a good practice
"The sum of 1 and 2 is equal to ${def a = 1; def b = 2; a + b}" 