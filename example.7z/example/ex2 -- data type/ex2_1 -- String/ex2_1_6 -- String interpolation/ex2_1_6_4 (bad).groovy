// also valid for dotted expressions of the form a.b, a.b.c, but NOT a good practice
// Expressions containing parentheses like 
// method calls, curly braces for closures, dots which aren’t part of a property expression or arithmetic operators 
// would be invalid.
def person = [name: 'Guillaume', age: 36]
assert "$person.name is $person.age years old" == 'Guillaume is 36 years old'