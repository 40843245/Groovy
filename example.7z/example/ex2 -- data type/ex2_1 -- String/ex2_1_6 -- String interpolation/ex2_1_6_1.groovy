def name = 'Guillaume' // a plain string
// string interpolation technique.
def greeting = "Hello ${name}"

assert greeting.toString() == 'Hello Guillaume'