def sumString1= "The sum of 2 and 3 equals ${2 + 3}"
assert sumString1.toString() == 'The sum of 2 and 3 equals 5'

