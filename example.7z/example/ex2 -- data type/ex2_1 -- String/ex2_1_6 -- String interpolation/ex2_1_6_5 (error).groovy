// You can think of "$number.toString()" as being interpreted by the parser as "${number.toString}()"
def number = 3.14

shouldFail(MissingPropertyException) {
    println "$number.toString()"
}