def myBooleanVariable = true
boolean untypedBooleanVar = false
booleanField = true