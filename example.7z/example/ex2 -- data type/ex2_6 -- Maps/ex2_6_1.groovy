// <table><tbody><tr><td class="content">When using names for the keys, we actually define string keys in the map.</td></tr></tbody></table>11
// <table><tbody><tr><td class="icon"><i class="fa icon-note" title="Note"></i></td><td class="content">Groovy creates maps that are actually instances of <code>java.util.LinkedHashMap</code>.</td></tr></tbody></table>
def colors = [red: '#FF0000', green: '#00FF00', blue: '#0000FF']   

assert colors['red'] == '#FF0000'    
assert colors.green  == '#00FF00'    

colors['pink'] = '#FF00FF'           
colors.yellow  = '#FFFF00'           

assert colors.pink == '#FF00FF'
assert colors['yellow'] == '#FFFF00'

assert colors instanceof java.util.LinkedHashMap

assert colors.unknown == null

def emptyMap = [:]
assert emptyMap.anyKey == null