def key = 'name'
def person = [key: 'Guillaume']      

assert !person.containsKey('name')   
assert person.containsKey('key')  

person = [(key): 'Guillaume']        

assert person.containsKey('name')    
assert !person.containsKey('key')    
