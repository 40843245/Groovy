def multi = [[0, 1], [2, 3]]     
assert multi[1][0] == 2  