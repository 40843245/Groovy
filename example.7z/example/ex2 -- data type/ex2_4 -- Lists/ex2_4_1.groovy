def numbers = [1, 2, 3]         

assert numbers instanceof List  
assert numbers.size() == 3 