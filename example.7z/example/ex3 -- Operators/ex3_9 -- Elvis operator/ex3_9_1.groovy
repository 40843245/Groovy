displayName = user.name ? user.name : 'Anonymous'   
displayName = user.name ?: 'Anonymous'  