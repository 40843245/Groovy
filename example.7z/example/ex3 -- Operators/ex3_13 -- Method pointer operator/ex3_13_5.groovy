// Also in Groovy 3 and above, you can obtain a method pointer to an instance method of a class. 
// This method pointer takes an additional parameter being the receiver instance to invoke the method on.
def instanceMethod = String.&toUpperCase
assert instanceMethod('foo') == 'FOO'