// To align with Java 8 method reference expectations, 
// in Groovy 3 and above, you can use new as the method name to obtain a method pointer to the constructor.
def foo  = BigInteger.&new
def fortyTwo = foo('42')
assert fortyTwo == 42G