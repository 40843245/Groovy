assert !false           
assert true && true     
assert true || false 