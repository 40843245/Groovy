def list = ['Grace','Rob','Emmy']
assert ('Emmy' in list)                     
assert ('Alex' !in list) 