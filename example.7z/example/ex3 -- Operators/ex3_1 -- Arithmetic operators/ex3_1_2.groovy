assert +3 == 3
assert -4 == 0 - 4

assert -(-1) == 1  