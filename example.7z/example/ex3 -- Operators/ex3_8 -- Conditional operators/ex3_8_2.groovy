if (string!=null && string.length()>0) {
    result = 'Found'
} else {
    result = 'Not found'
}