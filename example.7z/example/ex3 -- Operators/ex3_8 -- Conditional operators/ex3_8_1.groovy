assert (!true)    == false                      
assert (!'foo')   == false                      
assert (!'')      == true