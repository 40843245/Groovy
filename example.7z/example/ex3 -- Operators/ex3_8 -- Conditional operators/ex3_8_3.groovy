def result = (string!=null && string.length()>0) ? 'Found' : 'Not found'
result = string ? 'Found' : 'Not found'