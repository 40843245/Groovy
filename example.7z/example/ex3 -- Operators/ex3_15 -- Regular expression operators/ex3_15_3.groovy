assert 'two words' ==~ /\S+\s+\S+/
assert 'two words' ==~ /^\S+\s+\S+$/         
assert !(' leading space' ==~ /\S+\s+\S+/)   

def m1 = 'two words' =~ /^\S+\s+\S+$/
assert m1.size() == 1                          
def m2 = 'now three words' =~ /^\S+\s+\S+$/    
assert m2.size() == 0                          
def m3 = 'now three words' =~ /\S+\s+\S+/
assert m3.size() == 1                          
assert m3[0] == 'now three'
def m4 = ' leading space' =~ /\S+\s+\S+/
assert m4.size() == 1                          
assert m4[0] == 'leading space'
def m5 = 'and with four words' =~ /\S+\s+\S+/
assert m5.size() == 2                          
assert m5[0] == 'and with'
assert m5[1] == 'four words'