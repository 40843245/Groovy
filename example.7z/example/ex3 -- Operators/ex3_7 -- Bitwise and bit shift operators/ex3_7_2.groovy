assert 12.equals(3 << 2)           
assert 24L.equals(3L << 3)         
assert 48G.equals(3G << 4)         

assert 4095 == -200 >>> 20
assert -1 == -200 >> 20
assert 2G == 5G >> 1
assert -3G == -5G >> 1