String input = '42'
Integer num = (Integer) input  