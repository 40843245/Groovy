String input = '42'
Integer num = input as Integer 