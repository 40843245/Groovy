/// example of method overloading.
def methodA(Object o1, Object o2) { 'o/o' }
def methodA(Integer i, String  s) { 'i/s' }
def methodA(String  s, Integer i) { 's/i' }


assert methodA('foo', 42) == 's/i' // invoking the 3th overloaded method.

List<List<Object>> pairs = [['foo', 1], [2, 'bar'], [3, 4]]
assert pairs.collect { a, b -> method(a, b) } == ['s/i', 'i/s', 'o/o']  // invoking the 3th overloaded method, 2th one, 1th one respectively for each elements.