import groovy.transform.MapConstructor

@MapConstructor
class Animal{
    String name
    Integer age
    Double weight
    Double height

    def say(String message){
        return "An animal:${name} says ${message}"
    }

    def getBmi(){
        return weight/(height**2)
    }
}

@MapConstructor
class Person extends Animal{
    
    // overriding the say method of `Animal` class.
    def say(String message){
        return "An Person:${name} says ${message}"
    }
}

Animal tiger = Animal(name:"Tiger",age:2,weight:100.0,height:72)
Person nico = Person(name:"nico",age:20,weight:58.0,height:159.0)
println(tiger.say("Hoooo"))
println()
println(nico.say("NicoNicoNi"))
println()
println(tiger.getBmi())
println()
println(nico.getBmi())
