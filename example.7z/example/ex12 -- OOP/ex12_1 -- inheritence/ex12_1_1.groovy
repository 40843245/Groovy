class BaseClass{
    BaseClass(){
        println("constructor of BaseClass is called.")
    }
}

class DerivedClass extends BaseClass{
    DerivedClass(){
        println("constructor of DerivedClass is called.")
    }
}

def ConditionToBoolean(Boolean: condition){
    return "Boolean.${condition ? "TRUE" : "FALSE}"
}

BaseClass baseClass1 = new BaseClass()
println()
println("Is baseClass1 instance of BaseClass?${ConditionToBoolean(baseClass1 instanceof BaseClass)}")

BaseClass baseClass2 = new DerivedClass()
println()
println("Is baseClass2 instance of BaseClass?${ConditionToBoolean(baseClass2 instanceof BaseClass)}")
println("Is baseClass2 instance of DerivedClass?${ConditionToBoolean(baseClass2 instanceof DerivedClass)}")

DerivedClass derivedClass1 = new DerivedClass()
println()
println("Is derivedClass1 instance of DerivedClass?${ConditionToBoolean(derivedClass1 instanceof DerivedClass)}")
